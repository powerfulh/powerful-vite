import js from '@eslint/js'
import pluginVue from 'eslint-plugin-vue'
import tsLint from 'typescript-eslint'

// export default [
//     {
//         name: 'app/files-to-lint',
//         files: ['**/*.{js,mjs,jsx,vue}'],
//     },

//     {
//         name: 'app/files-to-ignore',
//         ignores: ['**/dist/**', '**/dist-ssr/**', '**/coverage/**'],
//     },

//     js.configs.recommended,
//     ...pluginVue.configs['flat/essential'],
//     // Custom
//     {
//         rules: {
//             indent: 'warn',
//             'vue/html-indent': ['warn', 4]
//         },
//     },
// ]

export default tsLint.config(
    // Official guide
    { ignores: ['*.d.ts', '**/coverage', '**/dist'] },
    {
        extends: [
            js.configs.recommended,
            ...tsLint.configs.recommended,
            ...pluginVue.configs['flat/recommended']
        ],
        files: ['**/*.{ts,vue}'],
        languageOptions: {
            ecmaVersion: 'latest',
            sourceType: 'module',
            // globals
            parserOptions: {
                parser: tsLint.parser
            }
        },
        // Custom
        rules: {
            indent: 'warn',
            'vue/html-indent': ['warn', 4]
        }
    }
)