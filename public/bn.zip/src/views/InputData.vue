<script setup lang="ts">
import { startGame } from '@/instance/player';

const testStorage: StorageBox = {
    name: 'Storage',
    money: 0,
    nanopod: 0
}
const testData: Player = {
    id: 'tester',
    level: 0,
    exp: 0,
    asset: [
        testStorage
    ]
}
</script>

<template>
    <main>
        <form>
            <input type="text">
        </form>
        <button @click="startGame(JSON.stringify(testData), () => $router.push({name: 'home'}))">
            Test
        </button>
    </main>
</template>