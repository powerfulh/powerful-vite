<script setup lang="ts">
import { getAsset } from '@/instance/player';

const tileCount = 40
const asset = getAsset()
</script>

<template>
    <main>
        <section class="tile">
            <div
                v-for="(item, i) in tileCount"
                :key="i"
                class="tile"
            >
                {{ asset[i]?.name || 'Empty tile' }}
            </div>
        </section>
        <section>
            <button @click="$router.push({name: 'InputData'})">
                Logout
            </button>
        </section>
    </main>
</template>

<style scoped lang="scss">
section.tile {
  display: flex;
  flex-wrap: wrap;
  .tile {
    width: 100px;
    height: 100px;
  }
}
</style>