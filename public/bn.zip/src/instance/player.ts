let i: Player

export function startGame(data: string, callback: () => void) {
    i = JSON.parse(data)
    callback()
}
export function getAsset() {
    return i.asset
}
export function needLogin() {
    return i == null
}