const max = 50
const requireList: Array<number> = []
const amount = 100

for(let i = 0; i < max; i++) {
    requireList.push(amount + i * 10)
}