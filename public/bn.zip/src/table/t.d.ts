interface Asset {
    name: string // pk
}
interface Player {
    id: string // pk
    level: number
    exp: number
    asset: Array<Asset>
}
interface StorageBox extends Asset {
    money: number
    nanopod: number
}